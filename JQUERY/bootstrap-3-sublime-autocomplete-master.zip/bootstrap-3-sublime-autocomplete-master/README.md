Bootstrap 3 Autocomplete for Sublime Text 3
=============

Sublime Text Autocomplete plugin for Bootstrap 3

![screenshot](screenshot.png)

### Credits
Created based on [UIKit Plugin](https://github.com/uikit/uikit-sublime)